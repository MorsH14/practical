import { Text } from "@react-email/components";
import Layout from "./reuseable/layout";
import ButtonLink from "./reuseable/button";

interface rejectedDocumentProps {
  firstName: string;
  rejectedDocumentLink: string;
}

export const RejectedDocument = ({ firstName, rejectedDocumentLink }: rejectedDocumentProps) => {
  return (
   <Layout firstName={firstName} preview="Document Rejected" header="Document Rejected">

  <Text style={text}>
    Unfortunately, the document you submitted did not meet our requirements and has been rejected.
  </Text>

  <Text style={text}>
    Please review the document guidelines and re-submit a valid document to continue your enrollment process.
  </Text>

  <ButtonLink href={rejectedDocumentLink}>
    Re-upload Document
  </ButtonLink>

  <Text style={text}>
    If you need help or have questions about the requirements, don&apos;t hesitate to contact our support team.
  </Text>
</Layout>


  );
};

export default RejectedDocument;

const text = {
  fontSize: "16px",
  color: "#404040",
  lineHeight: "26px",
};

const footer = {
  fontSize: "14px",
  color: "#888",
  marginTop: "32px",
  textAlign: "center" as const,
};