import { formatCurrency, getDateTimeString, getFormattedMessage } from "./utils/helpers";
import Layout from "./reuseable/layout";

interface Props {
  firstName: string;
  subject: string;
  amount: number;
  dueDate: string;
}

const text = {
  fontSize: "16px",
  lineHeight: "28px",
  marginBottom: "30px",
  color: "#404040",
};

export const PaymentReminder = ({ firstName, subject, amount, dueDate }: Props) => {
  const message = `How does it feel to embrace the thrill of being young and daring? We are excited as you are, congratulations once again on stepping into the realm of landlords.

We kindly remind you that your monthly subscription of "${formatCurrency(amount)}" was due for payment on "${getDateTimeString(dueDate, "date-only")}". Your prompt attention to this matter is appreciated, and we look forward to your timely response.

Be advised that late payment interest of (1.5%) maybe applied within 7days.

Thank you, and we’re eager to continue supporting you on your journey`;

  const messageHtml = getFormattedMessage(message);

  return (
    <Layout firstName={firstName} preview={subject}>
      <div
        style={text}
        dangerouslySetInnerHTML={{
          __html: messageHtml,
        }}
      />
    </Layout>
  );
};

export default PaymentReminder;
