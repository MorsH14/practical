import { Text } from "@react-email/components";
import Layout from "./reuseable/layout";
import ButtonLink from "./reuseable/button";

interface NewDocumentRequestProps {
  firstName: string;
  newDocumentRequestLink: string;
}

export const NewDocumentRequest = ({ firstName, newDocumentRequestLink }: NewDocumentRequestProps) => {
  return (
   <Layout firstName={firstName} preview="Document Submission Needed" header="Document Submission Required">

  <Text style={text}>
    We noticed that a required document is missing from your enrollment process. To proceed, please upload the following:
  </Text>

  <Text style={text}>
    <strong>Required Document:</strong> Valid ID (e.g., National ID, Driver&apos;s License, or Passport)
  </Text>

  <Text style={text}>
    Click the button below to upload your document securely:
  </Text>

  <ButtonLink  href={newDocumentRequestLink}>
    Upload Document
  </ButtonLink>

  <Text style={text}>
    If you've already submitted it recently, please disregard this message or contact us to confirm receipt.
  </Text>

</Layout>

  );
};

export default NewDocumentRequest;


const text = {
  fontSize: "16px",
  color: "#404040",
  lineHeight: "26px",
};