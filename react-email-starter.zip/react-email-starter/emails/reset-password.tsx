import { Text } from "@react-email/components";
import Layout from "./reuseable/layout";
import ButtonLink from "./reuseable/button";

interface DropboxResetPasswordEmailProps {
  firstName: string;
  resetPasswordLink: string;
}

export const ResetPassword = ({ firstName, resetPasswordLink }: DropboxResetPasswordEmailProps) => {
  return (
    <Layout hideFooter firstName={firstName} preview="Password reset request">
      <div>
        <Text style={text}>
          Someone recently requested a password reset for your account. If this was you, you can set a new password here:
        </Text>

        <ButtonLink href={resetPasswordLink}>Reset password</ButtonLink>

        <Text style={text}>
          If you don&apos;t want to change your password or didn&apos;t request this, just ignore and delete this message.
        </Text>
        <Text style={text}>To keep your account secure, please don&apos;t forward this email to anyone.</Text>
      </div>
    </Layout>
  );
};

export default ResetPassword;

const text = {
  fontSize: "16px",
  color: "#404040",
  lineHeight: "26px",
};
