import { Text } from "@react-email/components";
import Layout from "./reuseable/layout";
import ButtonLink from "./reuseable/button";

interface CommissionDisbursedProps {
  firstName: string;
  commissionDisbursedLink: string;
  reference: string;
  amount: string;
  date: string;
  status: string;
}

export const CommissionDisbursed = ({
  firstName,
  commissionDisbursedLink,
  reference,
  amount,
  date,
  status,
}: CommissionDisbursedProps) => {
  return (
    <Layout
      firstName={firstName}
      preview="Your Commission Has Been Disbursed"
      header="Commission Disbursed Successfully"
    >
      <Text style={text}>
        We're happy to inform you that your commission has been disbursed for:
      </Text>

      <table
        width="100%"
        cellPadding="0"
        cellSpacing="0"
        style={{
          margin: "20px 0",
          borderCollapse: "collapse",
          fontSize: "16px",
          color: "#404040",
          width: "100%",
        }}
      >
        <thead>
          <tr>
            <th style={thStyle}>Reference</th>
            <th style={thStyle}>Amount</th>
            <th style={thStyle}>Date</th>
            <th style={thStyle}>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style={tdStyle}>{reference}</td>
            <td style={tdStyle}>{amount}</td>
            <td style={tdStyle}>{date}</td>
            <td style={{ ...tdStyle, color: status.toLowerCase() === "successful" ? "green" : "red" }}>
              {status}
            </td>
          </tr>
        </tbody>
      </table>

      <Text style={text}>Thank you for your continued partnership.</Text>

      <ButtonLink href={commissionDisbursedLink}>View Commission Details</ButtonLink>
    </Layout>
  );
};

export default CommissionDisbursed;

const text = {
  fontSize: "16px",
  color: "#404040",
  lineHeight: "26px",
};

const thStyle = {
  textAlign: "left" as const,
  padding: "10px",
  backgroundColor: "#f4f4f4",
  borderBottom: "1px solid #ddd",
};

const tdStyle = {
  padding: "10px",
  borderBottom: "1px solid #eee",
};
