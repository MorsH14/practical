import { Text } from "@react-email/components";
import Layout from "./reuseable/layout";

interface Props {
  firstName: string;
}

const text = {
  fontSize: "16px",
  lineHeight: "28px",
  marginBottom: "30px",
};

const textNoBottom = {
  fontSize: "16px",
  lineHeight: "28px",
};

const nextSteps = [
  {
    bold: "Complete your profile:",
    normal: "Finish setting up your account in under a minute to unlock full access to all features.",
  },
  {
    bold: "Explore Properties:",
    normal: "Browse all available properties for purchase directly in the Home section.",
  },
  {
    bold: "Schedule appointments:",
    normal: "Easily schedule appointments or express interest in a property and our team will follow up promptly.",
  },
];

export const Welcome = ({ firstName }: Props) => {
  return (
    <Layout firstName={firstName} preview="Welcome to 1159Realty community">
      <Text style={text}>
        Congratulations on embracing a young and daring spirit! We are thrilled to welcome you to the 1159Realty community. Thank
        you for choosing us. It is truly an honor to have you as a valued client, and we are excited to assist you as you take the
        next steps in your real estate journey.
      </Text>

      <Text style={text}>Here is how to get started:</Text>

      <ul>
        {nextSteps?.map((step, index) => (
          <li className="mb-20" key={index}>
            <div style={textNoBottom}>
              <strong>{step.bold}</strong> {step.normal}
            </div>
          </li>
        ))}
      </ul>

      <Text style={text}>We look forward to supporting you every step of the way.</Text>

      <div style={textNoBottom}>Mo,</div>
      <div style={textNoBottom}>Customer Success Team,</div>
      <div style={textNoBottom}>1159Realty.</div>
    </Layout>
  );
};

export default Welcome;
