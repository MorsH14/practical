import { getFormattedMessage } from "./utils/helpers";
import Layout from "./reuseable/layout";

interface Props {
  firstName: string;
  subject: string;
  message: string;
}

const text = {
  fontSize: "16px",
  lineHeight: "28px",
  marginBottom: "30px",
  color: "#404040",
};

export const Campaign = ({ firstName, message, subject }: Props) => {
  const messageHtml = getFormattedMessage(message);

  return (
    <Layout firstName={firstName} preview={subject}>
      <div
        style={text}
        dangerouslySetInnerHTML={{
          __html: messageHtml,
        }}
      />
    </Layout>
  );
};

export default Campaign;