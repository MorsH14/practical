import { Text } from "@react-email/components";
import Layout from "./reuseable/layout";
import ButtonLink from "./reuseable/button";

interface RevocationDisbursedProps {
  firstName: string;
  supportLink: string;
}

export const RevocationDisbursed = ({ firstName, supportLink }: RevocationDisbursedProps) => {
  return (
   <Layout firstName={firstName} preview="You have been Revoked" header="Revocation Disbursed">

  <Text style={text}>
    We want to inform you that your enrollment has been revoked due to recent changes or policy violations. However, a disbursement has been processed as part of this action.
  </Text>


  <Text style={text}>
    If you have any questions regarding the revocation or disbursement, please reach out to our support team.
  </Text>

  <ButtonLink href={supportLink}>
    Contact Support
  </ButtonLink>

</Layout>


  );
};

export default RevocationDisbursed;

const heading = {
  fontWeight: 600,
  fontSize: "26px",
  letterSpacing: "-0.5px",
  textAlign: "center" as const,
};

const text = {
  fontSize: "16px",
  color: "#404040",
  lineHeight: "26px",
};