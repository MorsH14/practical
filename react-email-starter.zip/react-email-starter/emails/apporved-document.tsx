import { Text } from "@react-email/components";
import Layout from "./reuseable/layout";
import ButtonLink from "./reuseable/button";

interface ApprovedDocumentProps {
  firstName: string;
  dashboardLink: string;
}

export const ApprovedDocument = ({ firstName, dashboardLink }: ApprovedDocumentProps) => {
  return (
   <Layout firstName={firstName} preview="Your Document Has Been Approved" header="Document Approved">

  <Text >
    Great news! The document you submitted has been successfully reviewed and approved.
  </Text>

  <Text style={text} >
    You're now cleared to continue your enrollment process and access all relevant features.
  </Text>

  <ButtonLink
    href={dashboardLink}>
    Go to Dashboard
  </ButtonLink>

  <Text style={text}>
    If you have any further questions or need help, feel free to reach out to us.
  </Text>
</Layout>

  );
};

export default ApprovedDocument;

const text = {
  fontSize: "16px",
  color: "#404040",
  lineHeight: "26px",
};

const footer = {
  fontSize: "14px",
  color: "#888",
  marginTop: "32px",
  textAlign: "center" as const,
};