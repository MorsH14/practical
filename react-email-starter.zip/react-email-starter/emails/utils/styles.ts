export const nameLarge = {
  color: "#1d1c1d",
  fontSize: "26px",
  fontWeight: "600",
  margin: "30px 0",
  padding: "0",
  lineHeight: "42px",
};

export const nameRegular = {
  color: "#1d1c1d",
  fontSize: "18px",
  margin: "30px 0 10px 0",
  padding: "0",
  lineHeight: "42px",
};

export const propertyImg = {
  width: "90%",
  maxWidth: "400px",
  height: "auto",
  objectFit: "cover" as const,
  borderRadius: "10px",
};

export const propertyName = {
  fontSize: "18px",
  fontWeight: "500",
  color: "#404040",
  lineHeight: "26px",
  marginTop: "10px",
};
