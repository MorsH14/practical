import { Text } from "@react-email/components";
import Layout from "./reuseable/layout";
import ButtonLink from "./reuseable/button";

interface EnrollmentCancellationProps {
  firstName: string;
  reEnrollLink: string;
}

export const EnrollmentCancellation = ({ firstName, reEnrollLink }: EnrollmentCancellationProps) => {
  return (
    <Layout firstName={firstName} preview="Your Enrollment Has Been Cancelled" header="Enrollment Cancelled">

  <Text style={text}>
    We regret to inform you that your recent enrollment has been cancelled. This could be due to incomplete information, non-payment, or an internal review.
  </Text>

    <Text style={text}>
    If you have any questions or need support, feel free to contact our team.
  </Text>

  <ButtonLink href={reEnrollLink}>
    Contact Support
  </ButtonLink>

</Layout>

  );
};

export default EnrollmentCancellation 

const text = {
  fontSize: "16px",
  color: "#404040",
  lineHeight: "26px",
};