import { Img, Text } from "@react-email/components";
import Layout from "./reuseable/layout";
import { propertyImg, propertyName } from "./utils/styles";
import ButtonLink from "./reuseable/button";
import { getEnrollmentUrl } from "./utils/helpers";

interface Props {
  firstName: string;
  code: string;
  enrollmentId: string;
}

export const NewEnrollment = ({ firstName, enrollmentId }: Props) => {
  return (
    <Layout firstName={firstName} preview="You have been enrolled for a new property">
      <div>
        <Text style={text}>You have been enrolled for a new property:</Text>
        <Img
          src="https://res.cloudinary.com/dhbwt5fuw/image/upload/v1747138085/houses_and_land-5bfc3326c9e77c0051812eb3_qn0l7k.jpg"
          alt="Property image"
          style={propertyImg}
        />
        <div style={propertyName}>
          Villa Manor - <span style={text}>Ikeja, Lagos</span>
        </div>
        <Text style={text}>Click the button below to see more details about your enrollment.</Text>
        <ButtonLink href={getEnrollmentUrl(enrollmentId)}>See more details</ButtonLink>
      </div>
    </Layout>
  );
};

export default NewEnrollment;

const text = {
  fontSize: "16px",
  color: "#404040",
  lineHeight: "26px",
};
