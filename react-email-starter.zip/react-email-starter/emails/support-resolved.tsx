import { Text } from "@react-email/components";
import Layout from "./reuseable/layout";
interface SupportResolvedProps {
  firstName: string;
}

export const SupportResolved = ({ firstName }: SupportResolvedProps) => {
  return (
  <Layout firstName={firstName} preview="Support Request Resolved" header="Support Request Resolved">


  <Text style={text}>
    We&apos;re happy to let you know that your support request has been resolved. If there&apos;s anything else you need or if the issue persists, don&apos;t hesitate to reach out again.
  </Text>


  <Text style={text}>
    Thank you for reaching out to us — we're always here to help.
  </Text>

</Layout>


  );
};

export default SupportResolved;

const text = {
  fontSize: "16px",
  color: "#404040",
  lineHeight: "26px",
};

const footer = {
  fontSize: "14px",
  color: "#888",
  marginTop: "32px",
  textAlign: "center" as const,
};