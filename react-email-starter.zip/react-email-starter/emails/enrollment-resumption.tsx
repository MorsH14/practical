import { Text } from "@react-email/components";
import Layout from "./reuseable/layout";
import ButtonLink from "./reuseable/button";

interface EnrollmentResumptionProps {
  firstName: string;
  enrollmentResumptionLink: string;
}

export const EnrollmentResumption = ({ firstName, enrollmentResumptionLink }: EnrollmentResumptionProps) => {
  return (
   <Layout firstName={firstName} preview="Your Enrollment Has Been Resumed" header="Enrollment Resumption">

  <Text style={text}>
    Great news! Your enrollment has been successfully resumed. You now have full access to your property.
  </Text>

  <Text style={text}>
    To continue where you left off, simply log in to your dashboard:
  </Text>

  <ButtonLink href={enrollmentResumptionLink}>Go to Dashboard</ButtonLink>
</Layout>


  );
};

export default EnrollmentResumption;

const text = {
  fontSize: "16px",
  color: "#404040",
  lineHeight: "26px",
};