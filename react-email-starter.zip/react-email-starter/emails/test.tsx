import Campaign from "./campaign";
import ChangeEmailRequest, { ChangePhoneNumberRequest } from "./change-phonenumber";
import CommissionDisbursed, { PaymentReceipt } from "./commission-disbursed";
import NewEnrollment from "./new-enrollment";
import PaymentReminder from "./payment-reminder";
import ResetPassword from "./reset-password";
import VerifyEmail from "./verify-email";
import VerifyPhoneNumber from "./verify-phonenumber";
import Welcome from "./welcome";

const message = `I hope this message finds you well. Despite multiple reminders regarding your outstanding payment for the land you acquired from us, we regret to inform you that the company has decided to revoke your landownership as outlined in the contract of sales document.

This decision has been carefully considered, and we appreciate your understanding. Regarding the terms given, the seller retains the right to withdraw ownership after a maximum grace period of 32 days, which has now elapsed.

Please review and sign the attached revocation letter, and promptly return it to us via email at admin@1159realty.com . Alternatively, you may submit it in person to our office located at No. 23, Offa Road, Opposite Kwara State Registry, Ilorin, Kwara State.

It is crucial to complete this process without delay. Failure to do so will leave the company with no choice but to initiate the forced revocation of your land ownership.

Thank you for your immediate attention to this matter.`;
const Test = () => {
  return (
    <CommissionDisbursed
  firstName="James"
  commissionDisbursedLink="https://varcho.app/commissions/view"
  reference="#COMM-2025-0031"
  amount="₦250,000"
  date="June 4, 2025"
  status="Successful"
/>

  );
};
export default Test;
